# EarnX Frontend — Back4App migration package (first integration build)

This package preserves the uploaded frontend and introduces a Back4App/Parse compatibility adapter so the existing compiled frontend can be tested against Parse Server without manually rewriting every compiled route chunk.

## Before deployment

1. Deploy the matching Cloud Code package first: `EarnX_Back4App_CloudCode_Reviewed.zip`.
2. Open `back4app-config.js` and set `applicationId` and `javascriptKey` from your Back4App application settings.
3. Never put the Back4App Master Key in frontend files.
4. Deploy the complete contents of this ZIP to the same web hosting location and preserve the `assets/` folder structure.
5. The Parse JavaScript SDK is loaded from `https://unpkg.com/parse@5.3.0/dist/parse.min.js`. Your hosting environment must allow that script, or the SDK should be self-hosted.
6. Run the tests below in a test account before enabling real financial operations.

## What this build changes

- Replaces the frontend's Supabase client factory with `window.EarnXBack4App.createClient()`.
- Adds `earnx-back4app-compat.js`, which implements the subset of Supabase-style auth, query, RPC, and storage APIs used by the current compiled frontend.
- Adds `back4app-config.js` for the public Back4App Application ID, JavaScript Key, and Parse Server URL.
- Loads the Parse SDK and adapter before the frontend bundle on the six HTML entry documents.
- Maps `profiles.id` filters to `profiles.user_id` for compatibility with the Cloud Code profile model.

## Important limitations — do not treat this as production-verified

This is an integration build, not proof that every feature works against your live Back4App application. The app has not been run with your application credentials or tested against the deployed Cloud Code/database permissions.

- Google OAuth is not implemented by this adapter. The Google sign-in button will return an explanatory error until a Back4App-compatible OAuth flow is configured.
- Parse password-reset emails and callback behavior differ from Supabase. Test the complete reset flow and adjust the hosted reset URL/email template as needed.
- Parse files are stored as Parse Files, not in named Supabase Storage buckets. The adapter returns the Parse file URL; `createSignedUrl` is compatibility behavior and does not create a time-limited signed URL. Do not use it for confidential uploads without a separate access-control design.
- Generic direct database CRUD is translated to Parse queries. Back4App Class-Level Permissions and Cloud Code security triggers may reject direct writes, especially administrator CRUD. Those failures must be resolved by routing sensitive operations through the relevant Cloud Functions, not by exposing the Master Key in the browser.
- Parse object IDs and Supabase row IDs are not inherently identical. The adapter specifically maps `profiles.id` to `user_id`; other relationships need to be verified against the schema created by the first successful requests.
- Cloud Code operations that update multiple records may not be atomic. Do not use this build for live money/reward operations until duplicate claims, concurrent balance changes, authorization, and audit records are tested and hardened.

## Minimum test checklist

1. Confirm the browser console has no Parse initialization or missing script errors.
2. Register a test user and verify `_User` plus the `profiles` class/record are created.
3. Log out and log back in using the email address.
4. Test password reset from email to completion.
5. Test reading public settings, levels, tasks, and promotions.
6. Test each Cloud Function used by a normal user: activation submission, upgrade request, task completion, questionnaire completion, and withdrawal request.
7. Test administrator authorization with both a normal account and a real admin account.
8. Test upload and retrieval for receipts and admin media.
9. Verify rejected requests do not alter balances, create duplicate rewards, or change another user's records.

If a feature fails, capture the browser console error and the corresponding Back4App Cloud Code log. Do not disable permissions or put a Master Key in the frontend to work around it.
